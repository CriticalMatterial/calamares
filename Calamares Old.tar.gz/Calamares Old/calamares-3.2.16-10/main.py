#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# === This file is part of Calamares - <http://github.com/calamares> ===
#
#   Copyright 2014 - 2019, Philip Müller <philm@manjaro.org>
#   Copyright 2016, Artoo <artoo@manjaro.org>
#
#   Calamares is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   Calamares is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with Calamares. If not, see <http://www.gnu.org/licenses/>.

import libcalamares
import subprocess
from libcalamares.utils import check_target_env_call, target_env_call
from libcalamares.utils import *
import os


def run():
    """ Calls routine to copy over intel or amd ucode.
    :return:
    """
    root_mount_point = libcalamares.globalstorage.value("rootMountPoint")
    cpu_ucode = subprocess.getoutput("hwinfo --cpu | grep Vendor: -m1 | cut -d\'\"\' -f2")

    if cpu_ucode == "AuthenticAMD":
        subprocess.check_call(["cp", "/run/archiso/bootmnt/arch/boot/amd_ucode.img", root_mount_point + "/boot/amd_ucode.img"])
    elif cpu_ucode == "GenuineIntel":
        subprocess.check_call(["cp", "/run/archiso/bootmnt/arch/boot/intel_ucode.img", root_mount_point + "/boot/intel_ucode.img"])
    return None
